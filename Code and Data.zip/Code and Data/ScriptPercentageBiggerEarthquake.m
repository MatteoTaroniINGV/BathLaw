% Script to compute the percentage of the events followed by a stronger earthquake 
% during a selected space-time window

% load the seismic catalog in ZMAP format
Cat = importdata( 'CMT_Catalog_1980_2019_Depth50km.txt' ) ;

% input values:
MagnMin  = 6.0 ;           % minimum magnitude for the selection of events
DepthMax = 50 ;            % depht in km
BigEarthquakeMagn = 6.5 ;  % magnitude for the considered 'big earthquake'
TimeWindow = 60 ;          % days
SpaceWindow = 100 ;        % radius (km)

% compute the ercentage of the events followed by a stronger earthquake
% during a selected space-time window
[ Perc ] = PercentageBiggerEarthquake( Cat , MagnMin , DepthMax , BigEarthquakeMagn , TimeWindow , SpaceWindow ) ;

% show the resulting percentage
Perc

