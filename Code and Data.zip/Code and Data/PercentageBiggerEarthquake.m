function [ Perc ] = PercentageBiggerEarthquake( Catalog , MagnMin , DepthMax , BigEarthquakeMagn , TimeWindow , SpaceWindow )

%%% INPUT
%
% Catalog = earthquake catalog in ZMAP format
%
% MagnMin = minimum magnitude of completeness of the catalog
%
% DepthMax = maximum depth for the earthquake
%
% BigEarthquakeMagn = magnitude for the considered 'big earthquake'
%
% TimeWindow = length (in day) of the time window after the 'big earthquake'
%
% SpaceWindow = radius (in Km) of the circular space window around the 
%               epicenter of the 'big earthquake'
%
%
%%% OUPUT
%
% Perc = percentage of the events with a bigger earthquake in the 
%        space-time window


% select the events in the catalog 
CatalogOk = Catalog( Catalog( : , 6 ) >= MagnMin & ...
                     Catalog( : , 7 ) <= DepthMax , : ) ;
                
% compute the julian date of the earthquake
TimeEarthquake = datenum( CatalogOk( : , [ 3 , 4 , 5 , 8 , 9 , 10 ] ) ) ;



% 'for' loop to find the percentage of the events with a bigger earthquake in the 
%  selected space-time window

Count = 1 ; % counter for the cycle

for i = 1 : size( CatalogOk , 1 )
    
    % if the earthquake is big enough
    if ( CatalogOk( i , 6 ) >= BigEarthquakeMagn )
        
      % temporal distance from the 'big event'  
      TimeDistance = TimeEarthquake - TimeEarthquake( i ) ;
      
      % select the events in the time window
      CatalogOkTime = CatalogOk( TimeDistance <= TimeWindow & ...
                                 TimeDistance > 0 , : ) ;
      
      % spatial distance from the 'big event' ( Earth radius = 6371 Km )
      EarthquakeDistances = distance( CatalogOkTime( : , 2 ) , CatalogOkTime( : , 1 ) , ...
                                      CatalogOk(     i , 2 ) , CatalogOk(     i , 1 ) )*pi/180*6371 ;
                                  
      % select the events in the space window
      CatalogOkTimeDist = CatalogOkTime( EarthquakeDistances <= SpaceWindow , : ) ;
      
      % save the magnitude of the 'big shock'
      Data( Count , 1 ) = CatalogOk( i , 6 ) ;
      
      
      % if there is another earthquake in the time-space window
      if size( CatalogOkTimeDist , 1 ) > 0
          
          % save the maximum magnitude in the time-space window
          Data( Count , 2 ) = max( CatalogOkTimeDist( : , 6 ) ) ;
          
          
      else
          % if there is no eartquake in the time-space window save 'NaN'
          Data( Count , 2 )= NaN ;
          
      end
      
      % add one to the counter
      Count = Count + 1 ; 
      
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% percentage of the events with a bigger earthquake in the space-time window
Perc = sum( Data( : , 1 ) <= Data( : , 2 ) ) / size( Data , 1 ) * 100 ;


